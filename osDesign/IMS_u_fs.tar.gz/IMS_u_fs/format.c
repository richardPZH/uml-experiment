/*
 * 2012/2/7 IMS@SCUT nemosail@gmail.com
 * format.c
 *
 * This file is used at the first time you create the diskimg file.
 * It will format the disk image file.
 *
 * You should also write a format program to init this file, i.e. write its super block and bitmap  blocks data .
 *
*/

#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include "Global.h"
#include "Super_block.h"
#include "Files.h"

#define PROGRAM_NAME "format"

void print_usage( void );
unsigned long get_file_size(const char *filename);

int main ( int argc , char ** argv )
{

    if( argc != 2 )
    {
	print_usage();
	return 0;
    }

    fprintf( stderr , "This program wil format the %s file, continue? y/n : ", argv[1]);

    char in;
    in = getchar();

    if( 'y' != in && 'Y' != in )
    {
	fprintf( stderr , "format cancelled!\n");
	return 0;
    }

    int fd;
    if( (fd = open( argv[1] , O_WRONLY )) < 0 )
    {
	fprintf( stderr , "Error on open():%s\n", strerror( errno ) );
	return 1;
    }

    struct sb tSuperBlock;
    tSuperBlock.fs_size = (long)get_file_size( argv[1] ) / BLOCK_SIZE;
    tSuperBlock.first_blk = BLOCK_SIZE * ( SUPER_BLOCK_N + BITMAP_BLOCK_N );
    tSuperBlock.bitmap = BITMAP_BLOCK_N;

    printf("Disk image file: %s\nReady to Write :\nfs_size(in blocks)  : %ld \nfirst_blk(location) : %ld \nbitmap(in blocks)   : %ld\n\n", argv[1] , tSuperBlock.fs_size , tSuperBlock.first_blk , tSuperBlock.bitmap );


    //diskimage too small no way to do
    if( tSuperBlock.fs_size < (SUPER_BLOCK_N + BITMAP_BLOCK_N + 1 ) )
    {
	fprintf( stderr , "Diskimage file too small! Can't format, sorry!\n");
	exit(1);
    }

    //write super block
    lseek( fd , (off_t) 0 , SEEK_SET );
    
    ssize_t wc;
    wc = write( fd , (void *) &tSuperBlock , sizeof( tSuperBlock ));
    if( wc != sizeof( tSuperBlock ))
    {
	fprintf( stderr , "Error on write():%s\n",strerror(errno));
	exit(1); //it will help me to close file ?
    }
    //super block done

    //write bitmap block
    lseek( fd , (off_t) (SUPER_BLOCK_N * BLOCK_SIZE) , SEEK_SET );
    char buffer[BLOCK_SIZE];
    (void *) memset((void *) buffer , 0 , BLOCK_SIZE);

    int count;
    for( count=0; count < tSuperBlock.bitmap ; count++ )
    {
	wc = write( fd , (void *)buffer , BLOCK_SIZE);
	if( wc != BLOCK_SIZE )
	{
	    fprintf( stderr , "Error on write():%s\n",strerror(errno));
	    exit(1); //it will help me to close file ?
	}
    }

    //the first block is occupy by the root dir
    lseek( fd , SUPER_BLOCK_N * BLOCK_SIZE , SEEK_SET );
    char oc = 0x80;
    write( fd , (void *)&oc , sizeof( oc ));
    //bitmap block done

    //write data block. no much to do
    struct u_fs_disk_block root;
    memset( &root , 0 , sizeof( root ));
    root.size=0;
    root.nNextBlock=0;

    lseek( fd , tSuperBlock.first_blk , SEEK_SET );
    write( fd , (void*)&root , sizeof( root));

    (void) close(fd);

    //read and comfirm
    if( (fd = open( argv[1] , O_RDONLY )) < 0 )
    {
	fprintf( stderr , "Error on open():%s\n", strerror( errno ) );
	return 1;
    }

    struct sb uSuperBlock;

    read( fd , (void *)&uSuperBlock, sizeof( uSuperBlock ) );

    printf("Disk image file: %s\nAfter writing :\nfs_size(in blocks)  : %ld \nfirst_blk(location) : %ld \nbitmap(in blocks)   : %ld\n\n", argv[1] , uSuperBlock.fs_size , uSuperBlock.first_blk , uSuperBlock.bitmap );

    if( 0 == memcmp( (void*)&tSuperBlock , (void*)&uSuperBlock , sizeof( tSuperBlock) ))
    {
	printf("Check....OK. Format Complete!\n");
    }
    else
    {
	fprintf( stderr , "Check....FAILED. Format Failed!\n");
    }

    ( void ) close( fd );
    
    return 0;
}

void print_usage( void )
{
    fprintf( stderr , "Usage :\n\t%s Disk_Image_Name\n" ,  PROGRAM_NAME );
}

unsigned long get_file_size(const char *filename)
{

        struct stat buf;

	if(stat(filename, &buf)<0)
        {
	   return 0;
	}
	return (unsigned long)buf.st_size;
}
